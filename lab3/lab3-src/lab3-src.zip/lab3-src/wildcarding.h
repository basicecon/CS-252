void expandWildCard(char * processed, char * unprocessed);
bool isMatch(char *regularExp, char *stringToMatch);